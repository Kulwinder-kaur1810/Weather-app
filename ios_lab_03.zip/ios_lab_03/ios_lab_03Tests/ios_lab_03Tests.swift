//
//  ios_lab_03Tests.swift
//  ios_lab_03Tests
//
//  Created by Kulwinder Dhaliwal on 2024-11-03.
//

import Testing
@testable import ios_lab_03

struct ios_lab_03Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
